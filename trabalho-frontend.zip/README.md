# 🛒 Trabalho Front-End — Análise Comparativa e Página Responsiva

Este repositório contém um trabalho acadêmico completo de Front-End, com uma análise comparativa de três grandes sites de e-commerce e a implementação de uma página web responsiva chamada **TechMais**.

## 📊 Análise Comparativa
Foram analisados três websites do segmento de e-commerce:
- Amazon Brasil
- Mercado Livre
- Magazine Luiza

### Critérios avaliados:
- Estrutura de layout e organização do conteúdo
- Utilização de elementos HTML5 semânticos
- Implementação de design responsivo
- Recursos interativos com JavaScript
- Performance com ferramentas como Google Lighthouse

> A análise completa está no arquivo `analise_comparativa.pdf`.

## 💻 Página Desenvolvida: TechMais
Uma página fictícia de e-commerce responsiva, desenvolvida com:
- HTML5 semântico
- CSS3 (flexbox, grid e media queries)
- JavaScript (menu mobile e botão de rolagem suave)

### 📱 Responsividade:
- Compatível com desktops, tablets e celulares.

## 👨‍💻 Autor
Mauricio Junior — 2025
GitHub: [@st4rboy27](https://github.com/st4rboy27)
